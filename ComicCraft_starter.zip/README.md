# ComicCraft - AI Comic Story Creator

Starter implementation for the ComicCraft project.

## Features in this starter
- Web form for story prompt, character, setting, tone and art style
- Flask backend
- Gemini API story generation
- Four-panel comic story output

## Setup

1. Create a Python virtual environment.
2. Install packages:
   `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`.
4. Put your Gemini API key in `.env`.
5. Run:
   `python app.py`
6. Open the local URL shown by Flask.

## Important
This is a starter implementation, not a claim that it satisfies every Skill Wallet Epic. The exact Epic requirements should be checked against the official project PDF before final submission.
