import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from google import genai

load_dotenv()

app = Flask(__name__)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/generate-story")
def generate_story():
    data = request.get_json(silent=True) or {}
    prompt = data.get("prompt", "").strip()
    character = data.get("character", "Main character")
    setting = data.get("setting", "Fantasy world")
    tone = data.get("tone", "adventurous")
    art_style = data.get("art_style", "comic book")

    if not prompt:
        return jsonify({"error": "Please enter a story prompt."}), 400

    if client is None:
        return jsonify({
            "error": "GEMINI_API_KEY is not configured. Copy .env.example to .env and add your API key."
        }), 500

    instruction = f"""
Create a short comic-book story outline from these inputs.
Story prompt: {prompt}
Main character: {character}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Return exactly 4 panels. For each panel provide:
1. Panel title
2. Visual description
3. Dialogue/narration

Keep the story coherent and suitable for a student project demo.
"""

    try:
        response = client.models.generate_content(
            model="gemini-3.8-flash",
            contents=instruction,
        )
        return jsonify({"story": response.text})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

if __name__ == "__main__":
    app.run(debug=True)
