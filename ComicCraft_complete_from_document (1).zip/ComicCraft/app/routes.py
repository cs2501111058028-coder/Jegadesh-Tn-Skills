from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import ValidationError

from app.models import GenerationResponse, PromptRequest

router = APIRouter()


def get_service(request: Request):
    return request.app.state.comic_service


@router.get("/")
async def home(request: Request):
    templates = request.app.state.templates
    return templates.TemplateResponse(request=request, name="index.html", context={})


@router.post("/generate")
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        layout = get_service(request).generate(data)
        return request.app.state.templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={"layout": layout},
        )
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=exc.errors()) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/generate-comic/json", response_model=GenerationResponse)
async def generate_json(data: PromptRequest, request: Request):
    try:
        layout = get_service(request).generate(data)
        return GenerationResponse(
            success=True,
            comic_id=layout.comic_id,
            title=layout.title,
            pdf_url=layout.pdf_path,
            panels=layout.panels,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/download/{comic_id}")
async def download(comic_id: str, request: Request):
    settings = request.app.state.settings
    matches = list(settings.exports_dir.glob(f"{comic_id}_*.pdf"))
    if not matches:
        raise HTTPException(status_code=404, detail="PDF not found")
    return FileResponse(matches[0], media_type="application/pdf", filename=matches[0].name)


@router.get("/export-success")
async def export_success(request: Request):
    return request.app.state.templates.TemplateResponse(
        request=request, name="export_success.html", context={}
    )


@router.post("/test-image")
async def test_image(request: Request, prompt: str = Form(...)):
    from app.models import PanelOutline

    panel = PanelOutline(
        panel_number=1,
        title="Test Image",
        scene_description=prompt,
        image_prompt=prompt,
    )
    path = request.app.state.comic_service.images.generate_image("test", panel)
    return JSONResponse({"success": True, "image_url": path})


@router.get("/health")
async def health(request: Request):
    settings = request.app.state.settings
    return {
        "status": "ok",
        "app": settings.app_name,
        "environment": settings.app_env,
        "mock_ai": settings.mock_ai,
        "gemini_configured": bool(settings.gemini_api_key),
        "huggingface_configured": bool(settings.hf_api_key),
    }
