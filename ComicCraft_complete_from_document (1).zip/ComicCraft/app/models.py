from enum import Enum
from typing import List

from pydantic import BaseModel, Field, field_validator


class Tone(str, Enum):
    LIGHT_HEARTED = "light-hearted"
    DRAMATIC = "dramatic"
    POETIC = "poetic"
    FUNNY = "funny"


class ArtStyle(str, Enum):
    ANIME = "anime"
    PIXEL_ART = "pixel art"
    COMIC_BOOK = "comic book"
    REALISTIC = "realistic"


class PromptRequest(BaseModel):
    story_prompt: str = Field(..., min_length=5, max_length=2000)
    character_name: str = Field(..., min_length=1, max_length=100)
    setting: str = Field(..., min_length=1, max_length=100)
    tone: Tone = Tone.LIGHT_HEARTED
    art_style: ArtStyle = ArtStyle.COMIC_BOOK

    @field_validator("story_prompt", "character_name", "setting")
    @classmethod
    def clean_text(cls, value: str) -> str:
        value = " ".join(value.split())
        if not value:
            raise ValueError("This field cannot be empty.")
        return value


class PanelOutline(BaseModel):
    panel_number: int
    title: str
    scene_description: str
    image_prompt: str


class ComicOutline(BaseModel):
    title: str
    panels: List[PanelOutline]


class PanelStory(BaseModel):
    panel_number: int
    caption: str
    narration: str
    dialogue: str


class ComicStory(BaseModel):
    panels: List[PanelStory]


class ComicPanel(BaseModel):
    panel_number: int
    title: str
    scene_description: str
    image_prompt: str
    image_path: str
    caption: str
    narration: str
    dialogue: str


class ComicLayout(BaseModel):
    comic_id: str
    title: str
    panels: List[ComicPanel]
    pdf_path: str = ""


class GenerationResponse(BaseModel):
    success: bool
    comic_id: str
    title: str
    pdf_url: str
    panels: List[ComicPanel]
