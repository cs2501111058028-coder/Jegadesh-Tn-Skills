from pathlib import Path

from fpdf import FPDF

from app.models import ComicLayout
from app.utils.files import safe_filename


class ComicPDF(FPDF):
    pass


def save_pdf(layout: ComicLayout, exports_dir: Path, project_root: Path) -> str:
    filename = f"{layout.comic_id}_{safe_filename(layout.title)}.pdf"
    output_path = exports_dir / filename

    pdf = ComicPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout.panels:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, f"Panel {panel.panel_number}: {panel.title}")
        pdf.ln(2)

        image_file = project_root / panel.image_path.lstrip("/")
        if image_file.exists():
            pdf.image(str(image_file), x=15, y=35, w=180, h=100)
            pdf.set_y(140)

        pdf.set_font("Helvetica", "I", 10)
        pdf.multi_cell(0, 6, panel.scene_description)
        pdf.ln(3)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Caption")
        pdf.set_font("Helvetica", size=10)
        pdf.multi_cell(0, 6, panel.caption)
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Narration")
        pdf.set_font("Helvetica", size=10)
        pdf.multi_cell(0, 6, panel.narration)
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Dialogue")
        pdf.set_font("Helvetica", size=10)
        pdf.multi_cell(0, 6, panel.dialogue)

    pdf.output(str(output_path))
    return f"/static/exports/{filename}"
