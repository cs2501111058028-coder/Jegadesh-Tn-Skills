from google import genai
from google.genai import types

from app.config import Settings
from app.models import ComicOutline, PanelOutline, PromptRequest


class GeminiFlashService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = None
        if not settings.mock_ai:
            if not settings.gemini_api_key:
                raise RuntimeError("GEMINI_API_KEY is missing. Add it to .env or use MOCK_AI=true.")
            self.client = genai.Client(api_key=settings.gemini_api_key)

    def generate_outline(self, request: PromptRequest) -> ComicOutline:
        if self.settings.mock_ai:
            return self._mock_outline(request)

        prompt = f"""
Create a cohesive {self.settings.panel_count}-panel comic outline.
User story: {request.story_prompt}
Main character: {request.character_name}
Setting: {request.setting}
Tone: {request.tone.value}
Art style: {request.art_style.value}

Return exactly {self.settings.panel_count} panels. Each panel must have a clear title,
scene description, and detailed image prompt. Keep the same main character consistent
across all panels. Make the story have a beginning, conflict, development, and ending.
""".strip()

        response = self.client.models.generate_content(
            model=self.settings.gemini_outline_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=ComicOutline,
            ),
        )
        if getattr(response, "parsed", None):
            outline = response.parsed
            if isinstance(outline, ComicOutline):
                return outline
        if not response.text:
            raise RuntimeError("Gemini returned an empty outline response.")
        return ComicOutline.model_validate_json(response.text)

    def _mock_outline(self, request: PromptRequest) -> ComicOutline:
        panels = []
        beats = [
            ("A New Beginning", "The hero discovers an unusual clue that starts the adventure."),
            ("Into the Unknown", "The hero follows the clue and enters a fascinating part of the setting."),
            ("The Challenge", "An unexpected obstacle forces the hero to make a brave choice."),
            ("Turning Point", "The hero solves the central problem using creativity and courage."),
            ("A Bright Ending", "The adventure concludes with a satisfying and hopeful moment."),
        ]
        for i, (title, description) in enumerate(beats[: self.settings.panel_count], 1):
            panels.append(
                PanelOutline(
                    panel_number=i,
                    title=title,
                    scene_description=f"{request.character_name} in {request.setting}. {description}",
                    image_prompt=(
                        f"{request.character_name}, {request.setting}, {description} "
                        f"{request.art_style.value} style, {request.tone.value} mood, comic panel"
                    ),
                )
            )
        return ComicOutline(title=f"The Adventure of {request.character_name}", panels=panels)
