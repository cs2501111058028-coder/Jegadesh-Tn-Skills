from google import genai
from google.genai import types

from app.config import Settings
from app.models import ComicOutline, ComicStory, PanelStory


class GeminiProService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = None
        if not settings.mock_ai:
            if not settings.gemini_api_key:
                raise RuntimeError("GEMINI_API_KEY is missing. Add it to .env or use MOCK_AI=true.")
            self.client = genai.Client(api_key=settings.gemini_api_key)

    def generate_story(self, outline: ComicOutline) -> ComicStory:
        if self.settings.mock_ai:
            return self._mock_story(outline)

        prompt = f"""
Expand this comic outline into engaging comic narration.
Return one story object for every panel in the outline.
For every panel provide a short caption, narration, and natural character dialogue.
Keep characters, setting, events, and continuity consistent.

Outline:
{outline.model_dump_json(indent=2)}
""".strip()

        response = self.client.models.generate_content(
            model=self.settings.gemini_story_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=ComicStory,
            ),
        )
        if getattr(response, "parsed", None):
            story = response.parsed
            if isinstance(story, ComicStory):
                return story
        if not response.text:
            raise RuntimeError("Gemini returned an empty story response.")
        return ComicStory.model_validate_json(response.text)

    def _mock_story(self, outline: ComicOutline) -> ComicStory:
        return ComicStory(
            panels=[
                PanelStory(
                    panel_number=p.panel_number,
                    caption=f"Panel {p.panel_number}: {p.title}",
                    narration=p.scene_description,
                    dialogue="Let's see where this adventure leads!",
                )
                for p in outline.panels
            ]
        )
