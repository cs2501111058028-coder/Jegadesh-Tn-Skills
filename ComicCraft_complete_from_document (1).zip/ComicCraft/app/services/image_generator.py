from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from huggingface_hub import InferenceClient

from app.config import Settings
from app.models import PanelOutline
from app.utils.files import safe_filename


class ImageGenerator:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = None
        if not settings.mock_ai:
            if not settings.hf_api_key:
                raise RuntimeError("HF_API_KEY is missing. Add it to .env or use MOCK_AI=true.")
            self.client = InferenceClient(
                provider=settings.hf_provider,
                api_key=settings.hf_api_key,
            )

    def generate_image(self, comic_id: str, panel: PanelOutline) -> str:
        filename = f"{comic_id}_panel_{panel.panel_number}_{safe_filename(panel.title)}.png"
        output_path = self.settings.panels_dir / filename

        if self.settings.mock_ai:
            self._create_mock_image(output_path, panel)
        else:
            prompt = (
                f"{panel.image_prompt}. Clean comic illustration, clear composition, "
                "consistent character design, readable scene, high detail."
            )
            image = self.client.text_to_image(
                prompt,
                model=self.settings.hf_image_model,
                width=self.settings.image_width,
                height=self.settings.image_height,
                num_inference_steps=self.settings.image_steps,
                guidance_scale=self.settings.image_guidance,
            )
            image.save(output_path)

        return f"/static/panels/{filename}"

    def _create_mock_image(self, path: Path, panel: PanelOutline) -> None:
        image = Image.new("RGB", (self.settings.image_width, self.settings.image_height), "white")
        draw = ImageDraw.Draw(image)
        margin = 40
        draw.rectangle((margin, margin, image.width - margin, image.height - margin), outline="black", width=5)
        cx, cy = image.width // 2, image.height // 2
        draw.ellipse((cx - 90, cy - 160, cx + 90, cy + 20), outline="black", width=6)
        draw.line((cx, cy + 20, cx, cy + 220), fill="black", width=6)
        draw.line((cx, cy + 70, cx - 130, cy + 150), fill="black", width=6)
        draw.line((cx, cy + 70, cx + 130, cy + 150), fill="black", width=6)
        draw.line((cx, cy + 220, cx - 100, cy + 350), fill="black", width=6)
        draw.line((cx, cy + 220, cx + 100, cy + 350), fill="black", width=6)
        draw.text((60, 70), f"Panel {panel.panel_number}", fill="black")
        draw.text((60, image.height - 100), panel.title[:60], fill="black")
        image.save(path)
