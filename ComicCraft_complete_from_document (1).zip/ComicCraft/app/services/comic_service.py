from uuid import uuid4

from app.config import Settings
from app.models import ComicLayout, PromptRequest
from app.services.exporters import save_pdf
from app.services.gemini_flash import GeminiFlashService
from app.services.gemini_pro import GeminiProService
from app.services.image_generator import ImageGenerator
from app.services.layout_builder import build_comic_layout
from app.utils.files import write_json


class ComicService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.flash = GeminiFlashService(settings)
        self.pro = GeminiProService(settings)
        self.images = ImageGenerator(settings)

    def generate(self, request: PromptRequest) -> ComicLayout:
        comic_id = uuid4().hex
        outline = self.flash.generate_outline(request)
        if len(outline.panels) != self.settings.panel_count:
            raise RuntimeError(
                f"Expected {self.settings.panel_count} panels, received {len(outline.panels)}."
            )
        story = self.pro.generate_story(outline)
        image_paths = [self.images.generate_image(comic_id, panel) for panel in outline.panels]
        layout = build_comic_layout(comic_id, outline, story, image_paths)
        layout.pdf_path = save_pdf(layout, self.settings.exports_dir, self.settings.static_dir.parent)
        write_json(self.settings.exports_dir / f"{comic_id}.json", layout.model_dump())
        return layout
