import os
os.environ["MOCK_AI"] = "true"

from fastapi.testclient import TestClient
from app.main import app


def test_home():
    with TestClient(app) as client:
        response = client.get("/")
        assert response.status_code == 200
        assert "ComicCraft" in response.text


def test_generate_json_mock():
    with TestClient(app) as client:
        response = client.post("/generate-comic/json", json={
            "story_prompt": "A brave fox explores an enchanted forest.",
            "character_name": "Foxy",
            "setting": "forest",
            "tone": "funny",
            "art_style": "comic book"
        })
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert len(data["panels"]) == 5
        assert data["pdf_url"].endswith(".pdf")
