document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#comic-form');
  const button = document.querySelector('#generate-btn');
  const status = document.querySelector('#status');
  if (!form) return;
  form.addEventListener('submit', () => {
    button.disabled = true;
    button.textContent = 'Generating...';
    status.textContent = 'Generating outline, story, illustrations, and PDF. This can take a few minutes.';
  });
});
