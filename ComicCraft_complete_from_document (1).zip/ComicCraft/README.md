# ComicCraft - AI Comic Story Creator

ComicCraft is a FastAPI + Jinja2 web application based on the supplied project documentation. It accepts a story prompt, character, setting, tone, and art style, then creates a five-panel comic outline, narration/dialogue, illustrations, and a PDF export.

## Project flow

1. User submits story details.
2. Gemini Flash creates the five-panel structured outline.
3. Gemini Pro expands the outline into captions, narration, and dialogue.
4. Hugging Face Inference Providers / Stable Diffusion generates an image for each panel.
5. The layout builder combines text and images.
6. FPDF creates a PDF with consecutive panel pages.
7. The web preview shows the finished comic and a PDF download link.

## Requirements

- Windows/macOS/Linux
- Python 3.11+
- Gemini API key for real text generation
- Hugging Face token with inference permission for real image generation

## Windows setup

```powershell
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and edit the values.

### First test without API keys

```env
MOCK_AI=true
```

Then run:

```powershell
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

API docs: http://127.0.0.1:8000/docs

Run tests:

```powershell
pytest
```

## Real AI mode

Set:

```env
MOCK_AI=false
GEMINI_API_KEY=your_key
HF_API_KEY=your_token
```

The model IDs remain configurable in `.env`, so they can be changed without editing Python code.

## Main endpoints

- `GET /` - homepage
- `POST /generate` - form-based comic generation
- `POST /generate-comic/json` - JSON API generation
- `GET /download/{comic_id}` - PDF download
- `GET /export-success` - export confirmation page
- `POST /test-image` - image generation test
- `GET /health` - health/configuration status
- `GET /docs` - FastAPI Swagger documentation

## Output folders

Generated panel images are stored in `static/panels/` and PDF/metadata files in `static/exports/`.

## Notes

The supplied project document describes Gemini 1.5 Flash, Gemini 1.5 Pro, and Stable Diffusion v1.5. The implementation keeps model IDs configurable because hosted model availability can change. The Python code uses the current Google GenAI SDK pattern for structured Pydantic JSON output and the Hugging Face `InferenceClient.text_to_image` API.
