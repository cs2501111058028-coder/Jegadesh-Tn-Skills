# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI + Jinja2 web application that turns a user's story idea into a five-panel comic:

1. Gemini Flash creates a structured panel outline.
2. Gemini Pro creates narration and dialogue.
3. Hugging Face Diffusion inference creates one illustration per panel.
4. A layout builder combines text + images.
5. fpdf2 exports the comic as a downloadable PDF.

## Important implementation note

The original project document targets the older `google-generativeai` package and Gemini 1.5 model IDs. This implementation uses Google's current `google-genai` SDK and configurable current model IDs instead. The application keeps the same two-stage Flash/Pro architecture described in the document.

Image generation uses Hugging Face `InferenceClient` so the normal setup does not require downloading a multi-GB Stable Diffusion checkpoint onto the developer machine. The image model is configurable through `.env`.

## Requirements

- Python 3.11 or newer
- A Gemini API key
- A Hugging Face access token with inference permission
- VS Code
- Internet access for the hosted AI providers

## Project structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── models.py
│   ├── routes.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── gemini_flash.py
│   │   ├── gemini_pro.py
│   │   ├── image_generator.py
│   │   ├── comic_service.py
│   │   ├── layout_builder.py
│   │   └── exporters.py
│   └── utils/
│       ├── __init__.py
│       └── files.py
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── static/
│   ├── css/style.css
│   ├── js/app.js
│   ├── panels/.gitkeep
│   └── exports/.gitkeep
├── tests/
│   ├── __init__.py
│   ├── test_health.py
│   └── test_api_mock.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Windows setup in VS Code

Open the `ComicCraft` folder in VS Code.

### 1. Create a virtual environment

PowerShell:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```cmd
py -3.11 -m venv .venv
.venv\Scripts\activate.bat
```

### 2. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Create `.env`

Copy `.env.example` to `.env` and set:

```env
GEMINI_API_KEY=your_gemini_key
HF_API_KEY=your_huggingface_token
```

The defaults are:

```env
GEMINI_OUTLINE_MODEL=gemini-3.8-flash
GEMINI_STORY_MODEL=gemini-3.1-pro-preview
HF_IMAGE_MODEL=runwayml/stable-diffusion-v1-5
HF_PROVIDER=auto
```

If your Hugging Face account/provider does not expose the selected Stable Diffusion model, change `HF_IMAGE_MODEL` to a text-to-image model available to your account.

### 4. Run

```bash
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs

## First test without paid AI calls

The automated tests use mock AI responses:

```bash
pytest -q
```

The application itself will require valid provider credentials for real generation.

## API example

POST `/generate-comic/json`

```json
{
  "story_prompt": "A brave fox exploring an enchanted forest",
  "character_name": "Fenn",
  "setting": "enchanted forest",
  "tone": "dramatic",
  "art_style": "comic book"
}
```

## Useful routes

- `GET /` — homepage
- `POST /generate` — browser form generation
- `POST /generate-comic/json` — JSON API
- `GET /download/{comic_id}` — PDF download
- `GET /export-success` — export confirmation
- `POST /test-image` — image generation test
- `GET /health` — health check
- `GET /docs` — Swagger/OpenAPI UI

## Troubleshooting

### `GEMINI_API_KEY is not configured`

Create `.env` from `.env.example` and add the key.

### Hugging Face model/provider error

The Hugging Face ecosystem can route image generation through different providers and model availability changes over time. Set `HF_PROVIDER=auto` first. If a specific model is unavailable, replace `HF_IMAGE_MODEL` with a text-to-image model available in your Hugging Face account.

### Windows PDF/image problems

Keep the project path free of unusual permission restrictions. The application writes generated assets under `static/panels` and `static/exports`.

## Architecture

The implementation follows the project document's architecture: HTML/CSS/Jinja2 frontend, FastAPI backend, Gemini outline/story generation, image generation, layout building, and PDF export. The API is deliberately split into small service modules so each part can be replaced independently.
