from pathlib import Path

from fpdf import FPDF
from PIL import Image

from app.models import ComicLayout
from app.utils.files import safe_filename


class ComicPDF(FPDF):
    def header(self):
        self.set_font("Helvetica", "B", 16)
        self.cell(0, 10, "ComicCraft", ln=True, align="C")
        self.ln(2)


def save_pdf(
    layout: ComicLayout,
    exports_dir: Path,
    static_dir: Path,
) -> str:
    exports_dir.mkdir(parents=True, exist_ok=True)

    filename = f"{safe_filename(layout.comic_id)}.pdf"
    output_path = exports_dir / filename

    pdf = ComicPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout.panels:
        pdf.add_page()

        pdf.set_font("Helvetica", "B", 14)
        pdf.multi_cell(0, 8, f"Panel {panel.panel_number}: {panel.title}")
        pdf.ln(2)

        image_file = static_dir.parent / panel.image_path.lstrip("/").replace("/", "\\")
        # Normalize the path independently of the host OS.
        image_file = static_dir.parent / panel.image_path.lstrip("/").replace("/", "/")
        if not image_file.exists():
            raise FileNotFoundError(f"Panel image not found: {image_file}")

        with Image.open(image_file) as image:
            width, height = image.size

        max_width = 180
        max_height = 105
        scale = min(max_width / width, max_height / height)
        display_w = width * scale
        display_h = height * scale

        x = (210 - display_w) / 2
        pdf.image(str(image_file), x=x, w=display_w, h=display_h)
        pdf.ln(5)

        pdf.set_font("Helvetica", "I", 10)
        pdf.multi_cell(0, 6, panel.scene_description)
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 10)
        pdf.multi_cell(0, 6, f"Caption: {panel.caption}")

        pdf.set_font("Helvetica", "", 10)
        pdf.multi_cell(0, 6, f"Narration: {panel.narration}")
        if panel.dialogue:
            pdf.multi_cell(0, 6, f"Dialogue: {panel.dialogue}")

    pdf.output(str(output_path))
    return f"/static/exports/{filename}"
