import uuid

from app.config import Settings
from app.models import ComicLayout, PromptRequest
from app.services.exporters import save_pdf
from app.services.gemini_flash import GeminiFlashService
from app.services.gemini_pro import GeminiProService
from app.services.image_generator import ImageGenerator
from app.services.layout_builder import build_comic_layout
from app.utils.files import write_json


class ComicService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.flash = GeminiFlashService(settings)
        self.pro = GeminiProService(settings)
        self.images = ImageGenerator(settings)

    def generate(self, request: PromptRequest) -> ComicLayout:
        comic_id = uuid.uuid4().hex

        outline = self.flash.generate_outline(request)
        story = self.pro.generate_story(request, outline)

        image_paths = []
        for panel in outline.panels:
            image_paths.append(
                self.images.generate_image(
                    prompt=panel.image_prompt,
                    panel_number=panel.panel_number,
                    title=panel.title,
                    comic_id=comic_id,
                )
            )

        layout = build_comic_layout(
            comic_id=comic_id,
            outline=outline,
            story=story,
            image_paths=image_paths,
        )

        pdf_url = save_pdf(
            layout=layout,
            exports_dir=self.settings.exports_dir,
            static_dir=self.settings.static_dir,
        )

        data = layout.model_dump()
        data["pdf_url"] = pdf_url
        write_json(self.settings.exports_dir / f"{comic_id}.json", data)

        return layout

    def get_pdf_path(self, comic_id: str):
        path = self.settings.exports_dir / f"{comic_id}.pdf"
        return path if path.exists() else None
