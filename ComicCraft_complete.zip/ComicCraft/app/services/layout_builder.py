from app.models import ComicOutline, ComicStory, ComicLayout


def build_comic_layout(
    comic_id: str,
    outline: ComicOutline,
    story: ComicStory,
    image_paths: list[str],
) -> ComicLayout:
    story_by_panel = {panel.panel_number: panel for panel in story.panels}

    panels = []
    for index, outline_panel in enumerate(outline.panels):
        story_panel = story_by_panel[outline_panel.panel_number]
        panels.append(
            {
                "panel_number": outline_panel.panel_number,
                "title": outline_panel.title,
                "scene_description": outline_panel.scene_description,
                "image_prompt": outline_panel.image_prompt,
                "image_path": image_paths[index],
                "caption": story_panel.caption,
                "narration": story_panel.narration,
                "dialogue": story_panel.dialogue,
            }
        )

    return ComicLayout(comic_id=comic_id, panels=panels)
