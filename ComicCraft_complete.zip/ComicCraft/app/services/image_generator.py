from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from huggingface_hub import InferenceClient

from app.config import Settings
from app.utils.files import safe_filename


class ImageGenerator:
    """Generates panel art through Hugging Face Inference Providers."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = (
            InferenceClient(
                provider=settings.hf_provider,
                api_key=settings.hf_api_key,
            )
            if settings.hf_api_key
            else None
        )

    def generate_image(
        self,
        prompt: str,
        panel_number: int,
        title: str,
        comic_id: str,
    ) -> str:
        output_name = (
            f"{comic_id}_panel_{panel_number}_{safe_filename(title, 35)}.png"
        )
        output_path = self.settings.panels_dir / output_name

        if self.settings.mock_ai:
            self._create_mock_image(output_path, panel_number, title)
            return f"/static/panels/{output_name}"

        if not self.client:
            raise RuntimeError("HF_API_KEY is not configured.")

        final_prompt = (
            f"{prompt}. {self.settings.app_name} comic panel. "
            "Strong readable composition, consistent character design, "
            "clear foreground and background separation, no text or letters, "
            "family-friendly illustration."
        )

        image = self.client.text_to_image(
            final_prompt,
            model=self.settings.hf_image_model,
            width=self.settings.image_width,
            height=self.settings.image_height,
            num_inference_steps=self.settings.image_steps,
            guidance_scale=self.settings.image_guidance,
        )
        image.save(output_path)
        return f"/static/panels/{output_name}"

    @staticmethod
    def _create_mock_image(path: Path, panel_number: int, title: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        image = Image.new("RGB", (768, 768), "white")
        draw = ImageDraw.Draw(image)
        draw.rectangle((24, 24, 744, 744), outline="black", width=8)
        draw.ellipse((220, 160, 548, 488), outline="black", width=8)
        draw.line((384, 488, 300, 650), fill="black", width=8)
        draw.line((384, 488, 468, 650), fill="black", width=8)
        draw.text((55, 55), f"PANEL {panel_number}", fill="black")
        draw.text((55, 690), title[:50], fill="black")
        image.save(path)
