from google import genai

from app.config import Settings
from app.models import ComicOutline, PromptRequest


class GeminiFlashService:
    """Creates the structured panel-by-panel outline."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = (
            genai.Client(api_key=settings.gemini_api_key)
            if settings.gemini_api_key
            else None
        )

    def generate_outline(self, request: PromptRequest) -> ComicOutline:
        if self.settings.mock_ai:
            return ComicOutline(
                panels=[
                    {
                        "panel_number": i,
                        "title": f"Panel {i}",
                        "scene_description": (
                            f"{request.character_name} moves through the "
                            f"{request.setting} as the story develops."
                        ),
                        "image_prompt": (
                            f"{request.character_name}, {request.setting}, "
                            f"{request.art_style}, {request.tone}, comic panel, "
                            "cinematic composition, expressive character, detailed background"
                        ),
                    }
                    for i in range(1, self.settings.panel_count + 1)
                ]
            )

        if not self.client:
            raise RuntimeError("GEMINI_API_KEY is not configured.")

        prompt = f"""
Create a coherent {self.settings.panel_count}-panel comic outline.

User story idea:
{request.story_prompt}

Main character:
{request.character_name}

Setting:
{request.setting}

Tone:
{request.tone}

Art style:
{request.art_style}

Requirements:
- Return exactly {self.settings.panel_count} panels.
- Keep the same main character visually and narratively across panels.
- Each panel must advance the story.
- scene_description should describe the action, environment, and composition.
- image_prompt should be suitable for a diffusion image generator.
- Do not include copyrighted character names or imitate a living artist.
- Do not put dialogue in image_prompt.
"""

        response = self.client.models.generate_content(
            model=self.settings.gemini_outline_model,
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "response_schema": ComicOutline,
            },
        )

        parsed = getattr(response, "parsed", None)
        if parsed is not None:
            outline = parsed if isinstance(parsed, ComicOutline) else ComicOutline.model_validate(parsed)
        else:
            outline = ComicOutline.model_validate_json(response.text)

        if len(outline.panels) != self.settings.panel_count:
            raise RuntimeError(
                f"Gemini returned {len(outline.panels)} panels; "
                f"expected {self.settings.panel_count}."
            )
        return outline
