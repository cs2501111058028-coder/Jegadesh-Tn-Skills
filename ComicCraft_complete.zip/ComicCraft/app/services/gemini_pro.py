from google import genai

from app.config import Settings
from app.models import ComicOutline, ComicStory, PromptRequest


class GeminiProService:
    """Expands the outline into captions, narration, and dialogue."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = (
            genai.Client(api_key=settings.gemini_api_key)
            if settings.gemini_api_key
            else None
        )

    def generate_story(
        self,
        request: PromptRequest,
        outline: ComicOutline,
    ) -> ComicStory:
        if self.settings.mock_ai:
            return ComicStory(
                panels=[
                    {
                        "panel_number": p.panel_number,
                        "title": p.title,
                        "caption": f"The {request.tone} adventure continues.",
                        "narration": (
                            f"{request.character_name} takes another step through "
                            f"the {request.setting}, following the clues revealed "
                            "by the previous panel."
                        ),
                        "dialogue": (
                            f"{request.character_name}: We have to keep going!"
                        ),
                    }
                    for p in outline.panels
                ]
            )

        if not self.client:
            raise RuntimeError("GEMINI_API_KEY is not configured.")

        outline_json = outline.model_dump_json(indent=2)
        prompt = f"""
Write the complete narration for a five-panel comic using the outline below.

Story requirements:
- Story prompt: {request.story_prompt}
- Main character: {request.character_name}
- Setting: {request.setting}
- Tone: {request.tone}
- Art style: {request.art_style}

Outline:
{outline_json}

Return exactly one story object containing one entry per panel.
For every panel provide:
- title
- caption: a short comic caption
- narration: 1-3 vivid sentences
- dialogue: natural character dialogue; use an empty string when dialogue is unnecessary

Keep continuity between panels. Do not introduce unrelated characters or settings.
Do not use copyrighted franchise characters or copy existing stories.
"""

        response = self.client.models.generate_content(
            model=self.settings.gemini_story_model,
            contents=prompt,
            config={
                "response_mime_type": "application/json",
                "response_schema": ComicStory,
            },
        )

        parsed = getattr(response, "parsed", None)
        if parsed is not None:
            story = parsed if isinstance(parsed, ComicStory) else ComicStory.model_validate(parsed)
        else:
            story = ComicStory.model_validate_json(response.text)

        if len(story.panels) != len(outline.panels):
            raise RuntimeError("Story panel count does not match outline.")
        return story
