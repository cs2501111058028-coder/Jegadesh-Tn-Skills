from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=BASE_DIR / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = Field(default="ComicCraft", alias="APP_NAME")
    app_env: str = Field(default="development", alias="APP_ENV")
    mock_ai: bool = Field(default=False, alias="MOCK_AI")

    gemini_api_key: str = Field(default="", alias="GEMINI_API_KEY")
    gemini_outline_model: str = Field(
        default="gemini-3.8-flash", alias="GEMINI_OUTLINE_MODEL"
    )
    gemini_story_model: str = Field(
        default="gemini-3.1-pro-preview", alias="GEMINI_STORY_MODEL"
    )

    hf_api_key: str = Field(default="", alias="HF_API_KEY")
    hf_provider: str = Field(default="auto", alias="HF_PROVIDER")
    hf_image_model: str = Field(
        default="runwayml/stable-diffusion-v1-5", alias="HF_IMAGE_MODEL"
    )

    panel_count: int = Field(default=5, alias="PANEL_COUNT", ge=1, le=8)
    image_width: int = Field(default=768, alias="IMAGE_WIDTH", ge=256, le=1536)
    image_height: int = Field(default=768, alias="IMAGE_HEIGHT", ge=256, le=1536)
    image_steps: int = Field(default=20, alias="IMAGE_STEPS", ge=1, le=100)
    image_guidance: float = Field(default=7.5, alias="IMAGE_GUIDANCE", ge=1, le=30)

    static_dir: Path = BASE_DIR / "static"
    templates_dir: Path = BASE_DIR / "templates"

    @property
    def panels_dir(self) -> Path:
        return self.static_dir / "panels"

    @property
    def exports_dir(self) -> Path:
        return self.static_dir / "exports"

    def ensure_directories(self) -> None:
        self.static_dir.mkdir(parents=True, exist_ok=True)
        self.panels_dir.mkdir(parents=True, exist_ok=True)
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        self.templates_dir.mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    settings.ensure_directories()
    return settings
