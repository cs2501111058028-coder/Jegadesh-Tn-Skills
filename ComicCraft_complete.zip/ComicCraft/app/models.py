from typing import Literal

from pydantic import BaseModel, Field, field_validator


Tone = Literal["light-hearted", "dramatic", "poetic", "funny"]
ArtStyle = Literal["anime", "pixel art", "comic book", "realistic"]


class PromptRequest(BaseModel):
    story_prompt: str = Field(min_length=5, max_length=2000)
    character_name: str = Field(min_length=1, max_length=80)
    setting: str = Field(min_length=1, max_length=200)
    tone: Tone = "dramatic"
    art_style: ArtStyle = "comic book"

    @field_validator("story_prompt", "character_name", "setting")
    @classmethod
    def strip_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Value cannot be empty.")
        return value


class PanelOutline(BaseModel):
    panel_number: int = Field(ge=1)
    title: str = Field(min_length=1, max_length=120)
    scene_description: str = Field(min_length=1, max_length=1000)
    image_prompt: str = Field(min_length=1, max_length=1500)


class ComicOutline(BaseModel):
    panels: list[PanelOutline]


class PanelStory(BaseModel):
    panel_number: int = Field(ge=1)
    title: str
    caption: str
    narration: str
    dialogue: str


class ComicStory(BaseModel):
    panels: list[PanelStory]


class ComicPanel(BaseModel):
    panel_number: int
    title: str
    scene_description: str
    image_prompt: str
    image_path: str
    caption: str
    narration: str
    dialogue: str


class ComicLayout(BaseModel):
    comic_id: str
    panels: list[ComicPanel]


class GenerationResponse(BaseModel):
    comic_id: str
    message: str
    pdf_url: str
    layout: ComicLayout
