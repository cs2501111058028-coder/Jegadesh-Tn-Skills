import os

os.environ["MOCK_AI"] = "true"

from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_json_generation():
    payload = {
        "story_prompt": "A brave fox explores an enchanted forest.",
        "character_name": "Fenn",
        "setting": "enchanted forest",
        "tone": "dramatic",
        "art_style": "comic book",
    }

    response = client.post("/generate-comic/json", json=payload)

    assert response.status_code == 200
    body = response.json()
    assert body["comic_id"]
    assert body["pdf_url"].startswith("/download/")
    assert len(body["layout"]["panels"]) == 5


def test_homepage():
    response = client.get("/")
    assert response.status_code == 200
    assert "ComicCraft" in response.text
