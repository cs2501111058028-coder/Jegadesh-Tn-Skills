document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("[data-generation-form]");
  const status = document.querySelector("[data-status]");

  if (!form || !status) return;

  form.addEventListener("submit", () => {
    status.textContent =
      "Generating the outline, story, illustrations, and PDF. This can take a few minutes.";
    const button = form.querySelector("button[type=submit]");
    if (button) {
      button.disabled = true;
      button.textContent = "Generating...";
    }
  });
});
